var _____WB$wombat$assign$function_____ = function(name) {return (self._wb_wombat && self._wb_wombat.local_init && self._wb_wombat.local_init(name)) || self[name]; };
if (!self.__WB_pmw) { self.__WB_pmw = function(obj) { this.__WB_source = obj; return this; } }
{
  let window = _____WB$wombat$assign$function_____("window");
  let self = _____WB$wombat$assign$function_____("self");
  let document = _____WB$wombat$assign$function_____("document");
  let location = _____WB$wombat$assign$function_____("location");
  let top = _____WB$wombat$assign$function_____("top");
  let parent = _____WB$wombat$assign$function_____("parent");
  let frames = _____WB$wombat$assign$function_____("frames");
  let opener = _____WB$wombat$assign$function_____("opener");

document.write("<center><TABLE WIDTH=300 HEIGHT=15 BORDER=0 CELLPADDING=2 CELLSPACING=0 BGCOLOR=#6C8DBE background=\"\"><TR><TD><TABLE WIDTH=100% BORDER=0 CELLPADDING=0 CELLSPACING=0><TR><TD BGCOLOR=#6C8DBE><a href=\"http://top.addfreestats.com/web/main.cgi\" ><CENTER><FONT SIZE='1' FACE=\"Verdana, Arial, helvetica\"><FONT COLOR=#FFFFFF><b><I>&nbsp;In<FONT COLOR=#FFEE00>Live<FONT COLOR=#FFFFFF>!&nbsp&nbsp</I></B></A></FONT></CENTER></TD><TD BGCOLOR=#000000><a href=\"http://top.addfreestats.com/web/main.cgi\" ><CENTER><FONT FACE=\"Verdana, Arial, helvetica\" size='1'><FONT COLOR=#ffffff><b>&nbsp;2 visitors currently on the site.&nbsp</b></A></CENTER></FONT></TD></TR></TABLE></TD></TR></TABLE></center>");




}
/*
     FILE ARCHIVED ON 22:32:25 Oct 27, 2009 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 04:10:17 Nov 14, 2023.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  captures_list: 190.205
  exclusion.robots: 0.113
  exclusion.robots.policy: 0.1
  cdx.remote: 0.078
  esindex: 0.012
  LoadShardBlock: 161.127 (3)
  PetaboxLoader3.datanode: 50.615 (4)
  load_resource: 51.805
*/