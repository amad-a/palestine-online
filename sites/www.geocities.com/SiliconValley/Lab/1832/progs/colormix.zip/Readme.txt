RGB Color Mixer -- Version 1.0 -- January 3, 1997
CopyRight (C) 1996-1997 FS Software, Inc.
All Rights Reserved

*** Distribution ***

This program is Freeware.  It is not to be distributed for profit.


*** Purpose ***

"RGB Color Mixer" converts RGB base 10 values to their respective hexidecimal values and vice versa.  The user can also "mix" the colors by using the slide bar representations of the RGB values. The resultant hexidecimal value can be copied or cut to the clipboard. 


*** Installation ***

"RGB Mixer" will only run on Windows 95 or NT 4.0 operating systems. It was written in Visual Basic and requires that the following files be present in the windows\system directory:

olepro32.dll
vb40032.dll
msvcrt40.dll

These files are already available on Simtel.Net as vb40032.zip if you do not yet have them.  


*** Contact ***

Please email any comments or bugs to: stephenm@interramp.com


